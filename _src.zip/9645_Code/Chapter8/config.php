<?php

$config = array();
$config['db_ecom_host'] = 'localhost';
$config['db_ecom_user'] = 'root';
$config['db_ecom_pass'] = '';
$config['db_ecom_name'] = 'book4chapter8';

?>