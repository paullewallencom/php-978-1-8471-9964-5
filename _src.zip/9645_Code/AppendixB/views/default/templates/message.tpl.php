<h1>{header}</h1>
<p>{message}</p>