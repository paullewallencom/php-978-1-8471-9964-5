<h1>{pageheading}</h1>
{pagecontent}