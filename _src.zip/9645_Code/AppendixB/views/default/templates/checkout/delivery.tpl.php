<h1>Delivery address</h1>
<form action="checkout" method="post">
<input type="hidden" id="set_delivery_address" name="set_delivery_address" value="indeed" />
<input type="text" id="address_name" name="address_name" value="{address_name}" /> <br />
<input type="text" id="address_lineone" name="address_lineone" value="{address_lineone}" /> <br />
<input type="text" id="address_linetwo" name="address_linetwo" value="{address_linetwo}" /> <br />
<input type="text" id="address_city" name="address_city" value="{address_city}" /> <br />
<input type="text" id="address_postcode" name="address_postcode" value="{address_postcode}" /> <br />
<input type="text" id="address_country" name="address_country" value="{address_country}" /> <br />
<input type="submit" id="cd" name="cd" value="Confirm delivery address" />
</form>