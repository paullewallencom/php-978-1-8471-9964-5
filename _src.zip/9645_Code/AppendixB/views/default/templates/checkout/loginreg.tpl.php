<h1>Login</h1>
<form action="checkout" method="post">
<input type="text" id="ecomf_auth_user" name="ecomf_auth_user" />
<input type="password" id="ecomf_auth_pass" name="ecomf_auth_pass" />
<input type="submit" name="" id="" />
</form>
<h1>Register</h1>