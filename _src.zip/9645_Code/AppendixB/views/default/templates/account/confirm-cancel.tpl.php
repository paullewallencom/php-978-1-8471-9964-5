<h1>Are you sure you wish to cancel this order?</h1>
<p><a href="useraccount/cancel-order/{orderid}">Please cancel this order</a>.</p>