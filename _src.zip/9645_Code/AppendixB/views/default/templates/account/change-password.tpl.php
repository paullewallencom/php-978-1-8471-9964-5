<h1>Change password</h1>
<form action="useraccount/change-password" method="post">
<label for="">Old password</label>
<input type="password" id="old_password" name="old_password" /><br />
<label for="">Old password</label>
<input type="password" id="new_password" name="new_password" /><br />
<label for="">Old password</label>
<input type="password" id="confirm_newpassword" name="confirm_newpassword" /><br />
<input type="submit" id="cp" name="cp" value="Change password" />
</form>