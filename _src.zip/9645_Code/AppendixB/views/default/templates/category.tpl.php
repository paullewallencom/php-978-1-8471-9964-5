<h1>{category_heading}</h1>
{category_content}

{catproducts}
{subcats}