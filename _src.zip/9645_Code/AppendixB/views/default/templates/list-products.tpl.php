<h2>Products</h2>
<ul>
<!-- START products -->
<li><a href="products/view/{product_path}">{product_name}</a></li>
<!-- END products -->
</ul>

<!-- START filter_attribute_types -->
<h3>{filter_attr_name} {filter_attr_reference}</h3>
<ul>
<!-- START attribute_values_{filter_attr_reference} -->
<li><a href="{attribute_URL_extra}">{attribute_value}</a></li>
<!-- END attribute_values_{filter_attr_reference} -->
</ul>
<!-- END filter_attribute_types -->
