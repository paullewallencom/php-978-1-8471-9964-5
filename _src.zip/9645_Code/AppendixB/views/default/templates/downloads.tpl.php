<h1>Downloads</h1>
<ul>
<!-- START downloads -->
<li><a href="ourdownloadarea/{file}">{name}</a></li>
<!-- END downloads -->
</ul>