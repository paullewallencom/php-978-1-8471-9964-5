<h2>Review this product</h2>
<form action="contentcomment/{ID}" method="post">
<label for="comment_name">Your name</label>
<input type="text" id="comment_name" name="comment_name" />
<label for="comment_email">Your email address</label>
<input type="text" id="comment_email" name="comment_email" />
<label for="comment">Your review</label>
<textarea name="comment" id="comment"></textarea>
<input type="submit" id="savecomment" name="savecomment" value="Add review" />
</form>