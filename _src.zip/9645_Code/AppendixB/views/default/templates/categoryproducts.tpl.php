<h2>Products</h2>
<p>This category has the following products associated with it</p>
<ul>
<!-- START productlist -->
<li><a href="products/view/{product_path}">{product_name}</a></li>
<!-- END productlist -->
</ul>