<h2>Your wishlist</h2>
<ul>
<!-- START wishes -->
<li><a href="products/view/{product_path}">{product_name}</a></li>
<!-- END wishes -->
</ul>
