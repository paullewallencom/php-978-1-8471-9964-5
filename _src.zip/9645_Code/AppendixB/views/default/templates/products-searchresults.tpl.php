<h2>Products found...</h2>
<p>The following products were found, matching your search for {query}.</p>
<ul>
<!-- START results -->
<li><a href="products/view/{product_path}">{product_name}</a></li>
<!-- END results -->
</ul>


