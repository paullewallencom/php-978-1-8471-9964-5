<h2>Basket</h2>
<p>There are {numBasketItems} items totalling ${basketCost}</p>