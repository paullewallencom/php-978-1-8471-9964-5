<h2>Out of stock!</h2>
<p>We are <strong>really</strong> sorry, but this product is currently out of stock.  If you let us know your name and email address, we will let you know when it is back in stock.</p>
<form action="products/stockalert/{product_path}" method="post">
<label for="stock_name">Your name</label>
<input type="text" id="stock_name" name="stock_name" />
<label for="stock_email">Your email address</label>
<input type="text" id="stock_email" name="stock_email" />
<input type="submit" id="stock_submit" name="stock_submit" value="Let me know, when it is back in stock!" />
</form>
