<h2>Subcategories</h2>
<p>This category has the following subcategories</p>
<ul>
<!-- START subcatslist -->
<li><a href="categories/view/{category_path}">{category_name}</a></li>
<!-- END subcatslist -->
</ul>