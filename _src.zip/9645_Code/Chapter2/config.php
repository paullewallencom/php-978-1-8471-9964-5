<?php
 
$configs = array();

$configs['db_host_ecomframe'] = 'localhost';
$configs['db_user_ecomframe'] = 'root';
$configs['db_pass_ecomframe'] = '';
$configs['db_name_ecomframe'] = 'book4';

?>