<h2>{product_name}</h2>
{product_description}
<p>Cost: &pound;{product_price}, number in stock {product_stock}. Weight: {product_weight}Kg.</p>
<p>
<img src="product_images/{product_image}" alt="{product_name} image" />
</p>