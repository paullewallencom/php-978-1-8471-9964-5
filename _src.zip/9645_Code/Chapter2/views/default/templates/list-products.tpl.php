<h2>Products</h2>
<ul>
<!-- START products -->
<li><a href="products/view/{product_path}">{product_name}</a></li>
<!-- END products -->
</ul>